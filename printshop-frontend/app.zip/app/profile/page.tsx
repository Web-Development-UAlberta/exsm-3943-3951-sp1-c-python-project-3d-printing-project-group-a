/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { apiGet } from "../lib/api";

export default function ProfilePage() {
  // hardcoded user data — later comes from backend
  const [user, setUser] = useState<any>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const [userData, ordersData] = await Promise.all([
          apiGet("/users/me"),
          apiGet("/orders"),
        ]);
        setUser(userData);
        setOrders(ordersData.slice(0, 5));
      } catch (err: any) {
        console.log("Could not load profile");
      } finally {
        setLoading(false);
      }
    };
    loadProfile();
  }, []);

  const statusColor: Record<string, string> = {
    Pending: "bg-yellow-100 text-yellow-800",
    Printing: "bg-blue-100 text-blue-800",
    Shipped: "bg-purple-100 text-purple-800",
    Completed: "bg-green-100 text-green-800",
  };
  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-gray-300 border-t-gray-900 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div>
      {/* Profile Info */}
      <h1 className="text-2xl text-black font-bold mb-6">My profile</h1>
      <div className="bg-white border border-gray-200 rounded-lg p-6 mb-8">
        <div className="flex items-center gap-6 mb-6">
          <div className="w-16 h-16 bg-gray-300 rounded-full flex items-center justify-center">
            <span className="text-xl font-bold text-gray-600">
              {user.full_name
                ?.split(" ")
                .map((n: string) => n[0])
                .join("")
                .toUpperCase()}
            </span>
          </div>
          <div>
            <h2 className="text-lg text-black font-semibold">
              {user.full_name}
            </h2>
            <p className="text-sm text-gray-500">@{user.username}</p>
          </div>
        </div>

        <div>
          <p className="text-sm text-black">Email</p>
          <p className="text-sm text-gray-500 font-medium">{user.email}</p>
        </div>
        <div>
          <p className="text-sm text-black">Phone</p>
          <p className="text-sm text-gray-500 font-medium">
            {user.phone_number}
          </p>
        </div>
        <div>
          <p className="text-sm text-black">City</p>
          <p className="text-sm text-gray-500 font-medium">{user.city}</p>
        </div>
        <div>
          <p className="text-sm text-black">Postal code</p>
          <p className="text-sm text-gray-500 font-medium">
            {user.postal_code}
          </p>
        </div>

        <Link
          href="/profile/edit"
          className="mt-4 inline-block bg-gray-900 text-white px-6 py-2 rounded-lg text-sm font-medium hover:bg-gray-800"
        >
          Edit profile
        </Link>
      </div>

      {/* Order History */}
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-black">My orders</h2>
        <Link
          href="/orders"
          className="text-sm text-gray-600 hover:text-gray-900 underline"
        >
          View all orders
        </Link>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">
                Order ID
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">
                Item
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">
                Status
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">
                Ship date
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700"></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-t border-gray-100">
                <td className="px-4 py-3 text-sm text-gray-500 font-medium">
                  {order.order_header_id || order.id}
                </td>
                <td className="px-4 py-3 text-gray-500 text-sm">
                  {order.item || order.model_name || "--"}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs px-2 py-1 rounded-full font-medium ${statusColor[order.status]}`}
                  >
                    {order.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">
                  {order.date}
                </td>
                <td className="px-4 py-3">
                  {order.status === "Pending" && (
                    <button className="text-xs text-red-600 font-medium hover:text-red-800">
                      Cancel
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
