"""Initial Migration

Revision ID: 0cd4f77e0e19
Revises: 
Create Date: 2026-05-04 01:19:19.510392

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = '0cd4f77e0e19'
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('filament',
        sa.Column('filament_id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('material_name', sa.String(length=100), nullable=False),
        sa.Column('color_hex', sa.String(length=250), nullable=True),
        sa.Column('quantity_in_stock', sa.Float(), nullable=True),
        sa.Column('manufacturer', sa.String(length=100), nullable=True),
        sa.Column('more_wear_and_tear', sa.DECIMAL(precision=5, scale=2), nullable=True),
        sa.Column('finish_filament', sa.String(length=100), nullable=True),
        sa.Column('filament_price', sa.Float(), nullable=False),
        sa.PrimaryKeyConstraint('filament_id')
    )
    op.create_table('printer_type',
        sa.Column('printer_type_id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('printer_name', sa.String(length=100), nullable=True),
        sa.Column('max_size', sa.Float(), nullable=False),
        sa.PrimaryKeyConstraint('printer_type_id')
    )
    op.create_table('tag',
        sa.Column('tag_id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('tag_name', sa.String(length=100), nullable=False),
        sa.PrimaryKeyConstraint('tag_id'),
        sa.UniqueConstraint('tag_name')
    )
    op.create_table('users',
        sa.Column('user_id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('username', sa.String(length=200), nullable=False),
        sa.Column('full_name', sa.String(length=200), nullable=True),
        sa.Column('email', sa.String(length=250), nullable=True),
        sa.Column('phone_number', sa.String(length=15), nullable=False),
        sa.Column('city', sa.String(length=100), nullable=False),
        sa.Column('street_address', sa.String(length=250), nullable=False),
        sa.Column('province', sa.String(length=2), nullable=False),
        sa.Column('postal_code', sa.String(length=10), nullable=True),
        sa.Column('is_admin', sa.Boolean(), nullable=True),
        sa.PrimaryKeyConstraint('user_id'),
        sa.UniqueConstraint('email'),
        sa.UniqueConstraint('phone_number'),
        sa.UniqueConstraint('username')
    )
    op.create_table('order_header',
        sa.Column('order_header_id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('order_date', sa.Date(), nullable=False),
        sa.Column('shipping_price', sa.Float(), nullable=False),
        sa.Column('extra_fee', sa.Float(), nullable=True),
        sa.Column('total_price', sa.Float(), nullable=False),
        sa.Column('order_tracking_number', sa.String(length=200), nullable=True),
        sa.Column('order_status', sa.Enum('Pending', 'Printing', 'Shipped', 'Completed'), nullable=False),
        sa.Column('stripe_payment_id', sa.String(length=500), nullable=True),
        sa.Column('payment_date', sa.Date(), nullable=True),
        sa.Column('payment_status', sa.Enum('Pending', 'Succeeded', 'Failed'), nullable=True),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.user_id']),
        sa.PrimaryKeyConstraint('order_header_id'),
        sa.UniqueConstraint('order_tracking_number')
    )
    op.create_table('printer',
        sa.Column('printer_id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('filament_id', sa.Integer(), nullable=True),
        sa.Column('printer_type_id', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['filament_id'], ['filament.filament_id']),
        sa.ForeignKeyConstraint(['printer_type_id'], ['printer_type.printer_type_id']),
        sa.PrimaryKeyConstraint('printer_id')
    )
    op.create_table('model',
        sa.Column('model_id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('model_name', sa.String(length=100), nullable=False),
        sa.Column('model_length', sa.Float(), nullable=True),
        sa.Column('model_width', sa.Float(), nullable=True),
        sa.Column('model_height', sa.Float(), nullable=True),
        sa.Column('model_description', sa.Text(), nullable=True),
        sa.Column('model_file', sa.String(length=500), nullable=True),
        sa.Column('tag_id', sa.Integer(), nullable=True),
        sa.Column('printer_id', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['printer_id'], ['printer.printer_id']),
        sa.ForeignKeyConstraint(['tag_id'], ['tag.tag_id']),
        sa.PrimaryKeyConstraint('model_id')
    )
    op.create_table('model_filament',
        sa.Column('model_id', sa.Integer(), nullable=False),
        sa.Column('filament_id', sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(['filament_id'], ['filament.filament_id']),
        sa.ForeignKeyConstraint(['model_id'], ['model.model_id']),
        sa.PrimaryKeyConstraint('model_id', 'filament_id')
    )
    op.create_table('order_detail',
        sa.Column('order_detail_id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('order_quantity', sa.Integer(), nullable=True),
        sa.Column('infill_percent', sa.DECIMAL(precision=5, scale=2), nullable=True),
        sa.Column('scale', sa.Float(), nullable=True),
        sa.Column('unit_price', sa.Float(), nullable=True),
        sa.Column('model_id', sa.Integer(), nullable=True),
        sa.Column('order_header_id', sa.Integer(), nullable=True),
        sa.Column('filament_id', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['filament_id'], ['filament.filament_id']),
        sa.ForeignKeyConstraint(['model_id'], ['model.model_id']),
        sa.ForeignKeyConstraint(['order_header_id'], ['order_header.order_header_id']),
        sa.PrimaryKeyConstraint('order_detail_id')
    )


def downgrade() -> None:
    op.drop_table('order_detail')
    op.drop_table('model_filament')
    op.drop_table('model')
    op.drop_table('printer')
    op.drop_table('order_header')
    op.drop_table('users')
    op.drop_table('tag')
    op.drop_table('printer_type')
    op.drop_table('filament')